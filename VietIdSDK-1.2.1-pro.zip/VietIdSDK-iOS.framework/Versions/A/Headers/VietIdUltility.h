//
//  Ultility.h
//  VietIdSDK-iOS
//
//  Created by Le Minh Son on 11/29/18.
//  Copyright © 2018 songoku20. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface VietIdUltility : NSObject
+(NSString *_Nullable)systemDeviceTypeFormatted:(BOOL)formatted;

+ (NSString*)getUniqueIDForApp;

+ (NSData *)AES128Encrypt:(NSData *)data;

+ (NSData *)AES128Decrypt:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
