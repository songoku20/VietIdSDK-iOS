//
//  VietIdKeyChainStore.h
//  VietIdKeyChainStore
//
//  Created by Kishikawa Katsumi on 11/11/20.
//  Copyright (c) 2011 Kishikawa Katsumi. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const VietIDKeyChainStoreErrorDomain;

typedef NS_ENUM(NSInteger, VietIdKeyChainStoreErrorCode) {
    VietIdKeyChainStoreErrorInvalidArguments = 1,
};

typedef NS_ENUM(NSInteger, VietIDKeyChainStoreItemClass) {
    VietIdKeyChainStoreItemClassGenericPassword = 1,
    VietIdKeyChainStoreItemClassInternetPassword,
};

typedef NS_ENUM(NSInteger, VietIDKeyChainStoreProtocolType) {
    VietIdKeyChainStoreProtocolTypeFTP = 1,
    VietIdKeyChainStoreProtocolTypeFTPAccount,
    VietIdKeyChainStoreProtocolTypeHTTP,
    VietIdKeyChainStoreProtocolTypeIRC,
    VietIdKeyChainStoreProtocolTypeNNTP,
    VietIdKeyChainStoreProtocolTypePOP3,
    VietIdKeyChainStoreProtocolTypeSMTP,
    VietIdKeyChainStoreProtocolTypeSOCKS,
    VietIdKeyChainStoreProtocolTypeIMAP,
    VietIdKeyChainStoreProtocolTypeLDAP,
    VietIdKeyChainStoreProtocolTypeAppleTalk,
    VietIdKeyChainStoreProtocolTypeAFP,
    VietIdKeyChainStoreProtocolTypeTelnet,
    VietIdKeyChainStoreProtocolTypeSSH,
    VietIdKeyChainStoreProtocolTypeFTPS,
    VietIdKeyChainStoreProtocolTypeHTTPS,
    VietIdKeyChainStoreProtocolTypeHTTPProxy,
    VietIdKeyChainStoreProtocolTypeHTTPSProxy,
    VietIdKeyChainStoreProtocolTypeFTPProxy,
    VietIdKeyChainStoreProtocolTypeSMB,
    VietIdKeyChainStoreProtocolTypeRTSP,
    VietIdKeyChainStoreProtocolTypeRTSPProxy,
    VietIdKeyChainStoreProtocolTypeDAAP,
    VietIdKeyChainStoreProtocolTypeEPPC,
    VietIdKeyChainStoreProtocolTypeNNTPS,
    VietIdKeyChainStoreProtocolTypeLDAPS,
    VietIdKeyChainStoreProtocolTypeTelnetS,
    VietIdKeyChainStoreProtocolTypeIRCS,
    VietIdKeyChainStoreProtocolTypePOP3S,
};

typedef NS_ENUM(NSInteger, VietIdKeyChainStoreAuthenticationType) {
    VietIdKeyChainStoreAuthenticationTypeNTLM = 1,
    VietIdKeyChainStoreAuthenticationTypeMSN,
    VietIdKeyChainStoreAuthenticationTypeDPA,
    VietIdKeyChainStoreAuthenticationTypeRPA,
    VietIdKeyChainStoreAuthenticationTypeHTTPBasic,
    VietIdKeyChainStoreAuthenticationTypeHTTPDigest,
    VietIdKeyChainStoreAuthenticationTypeHTMLForm,
    VietIdKeyChainStoreAuthenticationTypeDefault,
};

typedef NS_ENUM(NSInteger, VietIdKeyChainStoreAccessibility) {
    VietIdKeyChainStoreAccessibilityWhenUnlocked = 1,
    VietIdKeyChainStoreAccessibilityAfterFirstUnlock,
    VietIdKeyChainStoreAccessibilityAlways,
    VietIdKeyChainStoreAccessibilityWhenPasscodeSetThisDeviceOnly
    __OSX_AVAILABLE_STARTING(__MAC_10_10, __IPHONE_8_0),
    VietIdKeyChainStoreAccessibilityWhenUnlockedThisDeviceOnly,
    VietIdKeyChainStoreAccessibilityAfterFirstUnlockThisDeviceOnly,
    VietIdKeyChainStoreAccessibilityAlwaysThisDeviceOnly,
}
__OSX_AVAILABLE_STARTING(__MAC_10_9, __IPHONE_4_0);

typedef NS_ENUM(NSInteger, VietIdKeyChainStoreAuthenticationPolicy) {
    VietIdKeyChainStoreAuthenticationPolicyUserPresence = kSecAccessControlUserPresence,
};

@interface VietIdKeyChainStore : NSObject

@property (nonatomic, readonly) VietIDKeyChainStoreItemClass itemClass;

@property (nonatomic, readonly) NSString *service;
@property (nonatomic, readonly) NSString *accessGroup;

@property (nonatomic, readonly) NSURL *server;
@property (nonatomic, readonly) VietIDKeyChainStoreProtocolType protocolType;
@property (nonatomic, readonly) VietIdKeyChainStoreAuthenticationType authenticationType;

@property (nonatomic) VietIdKeyChainStoreAccessibility accessibility;
@property (nonatomic, readonly) VietIdKeyChainStoreAuthenticationPolicy authenticationPolicy
__OSX_AVAILABLE_STARTING(__MAC_10_10, __IPHONE_8_0);

@property (nonatomic) BOOL synchronizable;

@property (nonatomic) NSString *authenticationPrompt
__OSX_AVAILABLE_STARTING(__MAC_NA, __IPHONE_8_0);

@property (nonatomic, readonly) NSArray *allKeys;
@property (nonatomic, readonly) NSArray *allItems;

+ (NSString *)defaultService;
+ (void)setDefaultService:(NSString *)defaultService;

+ (VietIdKeyChainStore *)keyChainStore;
+ (VietIdKeyChainStore *)keyChainStoreWithService:(NSString *)service;
+ (VietIdKeyChainStore *)keyChainStoreWithService:(NSString *)service accessGroup:(NSString *)accessGroup;

+ (VietIdKeyChainStore *)keyChainStoreWithServer:(NSURL *)server protocolType:(VietIDKeyChainStoreProtocolType)protocolType;
+ (VietIdKeyChainStore *)keyChainStoreWithServer:(NSURL *)server protocolType:(VietIDKeyChainStoreProtocolType)protocolType authenticationType:(VietIdKeyChainStoreAuthenticationType)authenticationType;

- (instancetype)init;
- (instancetype)initWithService:(NSString *)service;
- (instancetype)initWithService:(NSString *)service accessGroup:(NSString *)accessGroup;

- (instancetype)initWithServer:(NSURL *)server protocolType:(VietIDKeyChainStoreProtocolType)protocolType;
- (instancetype)initWithServer:(NSURL *)server protocolType:(VietIDKeyChainStoreProtocolType)protocolType authenticationType:(VietIdKeyChainStoreAuthenticationType)authenticationType;

+ (NSString *)stringForKey:(NSString *)key;
+ (NSString *)stringForKey:(NSString *)key service:(NSString *)service;
+ (NSString *)stringForKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup;
+ (BOOL)setString:(NSString *)value forKey:(NSString *)key;
+ (BOOL)setString:(NSString *)value forKey:(NSString *)key service:(NSString *)service;
+ (BOOL)setString:(NSString *)value forKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup;

+ (NSData *)dataForKey:(NSString *)key;
+ (NSData *)dataForKey:(NSString *)key service:(NSString *)service;
+ (NSData *)dataForKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup;
+ (BOOL)setData:(NSData *)data forKey:(NSString *)key;
+ (BOOL)setData:(NSData *)data forKey:(NSString *)key service:(NSString *)service;
+ (BOOL)setData:(NSData *)data forKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup;

- (BOOL)contains:(NSString *)key;

- (BOOL)setString:(NSString *)string forKey:(NSString *)key;
- (BOOL)setString:(NSString *)string forKey:(NSString *)key label:(NSString *)label comment:(NSString *)comment;
- (NSString *)stringForKey:(NSString *)key;

- (BOOL)setData:(NSData *)data forKey:(NSString *)key;
- (BOOL)setData:(NSData *)data forKey:(NSString *)key label:(NSString *)label comment:(NSString *)comment;
- (NSData *)dataForKey:(NSString *)key;

+ (BOOL)removeItemForKey:(NSString *)key;
+ (BOOL)removeItemForKey:(NSString *)key service:(NSString *)service;
+ (BOOL)removeItemForKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup;

+ (BOOL)removeAllItems;
+ (BOOL)removeAllItemsForService:(NSString *)service;
+ (BOOL)removeAllItemsForService:(NSString *)service accessGroup:(NSString *)accessGroup;

- (BOOL)removeItemForKey:(NSString *)key;

- (BOOL)removeAllItems;

- (NSString *)objectForKeyedSubscript:(NSString <NSCopying> *)key;
- (void)setObject:(NSString *)obj forKeyedSubscript:(NSString <NSCopying> *)key;

+ (NSArray *)allKeysWithItemClass:(VietIDKeyChainStoreItemClass)itemClass;
- (NSArray *)allKeys;

+ (NSArray *)allItemsWithItemClass:(VietIDKeyChainStoreItemClass)itemClass;
- (NSArray *)allItems;

- (void)setAccessibility:(VietIdKeyChainStoreAccessibility)accessibility authenticationPolicy:(VietIdKeyChainStoreAuthenticationPolicy)authenticationPolicy
__OSX_AVAILABLE_STARTING(__MAC_10_10, __IPHONE_8_0);

#if TARGET_OS_IPHONE
- (void)sharedPasswordWithCompletion:(void (^)(NSString *account, NSString *password, NSError *error))completion;
- (void)sharedPasswordForAccount:(NSString *)account completion:(void (^)(NSString *password, NSError *error))completion;

- (void)setSharedPassword:(NSString *)password forAccount:(NSString *)account completion:(void (^)(NSError *error))completion;
- (void)removeSharedPasswordForAccount:(NSString *)account completion:(void (^)(NSError *error))completion;

+ (void)requestSharedWebCredentialWithCompletion:(void (^)(NSArray *credentials, NSError *error))completion;
+ (void)requestSharedWebCredentialForDomain:(NSString *)domain account:(NSString *)account completion:(void (^)(NSArray *credentials, NSError *error))completion;

+ (NSString *)generatePassword;
#endif

@end

@interface VietIdKeyChainStore (ErrorHandling)

+ (NSString *)stringForKey:(NSString *)key error:(NSError * __autoreleasing *)error;
+ (NSString *)stringForKey:(NSString *)key service:(NSString *)service error:(NSError * __autoreleasing *)error;
+ (NSString *)stringForKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup error:(NSError * __autoreleasing *)error;

+ (BOOL)setString:(NSString *)value forKey:(NSString *)key error:(NSError * __autoreleasing *)error;
+ (BOOL)setString:(NSString *)value forKey:(NSString *)key service:(NSString *)service error:(NSError * __autoreleasing *)error;
+ (BOOL)setString:(NSString *)value forKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup error:(NSError * __autoreleasing *)error;

+ (NSData *)dataForKey:(NSString *)key error:(NSError * __autoreleasing *)error;
+ (NSData *)dataForKey:(NSString *)key service:(NSString *)service error:(NSError * __autoreleasing *)error;
+ (NSData *)dataForKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup error:(NSError * __autoreleasing *)error;

+ (BOOL)setData:(NSData *)data forKey:(NSString *)key error:(NSError * __autoreleasing *)error;
+ (BOOL)setData:(NSData *)data forKey:(NSString *)key service:(NSString *)service error:(NSError * __autoreleasing *)error;
+ (BOOL)setData:(NSData *)data forKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup error:(NSError * __autoreleasing *)error;

- (BOOL)setString:(NSString *)string forKey:(NSString *)key error:(NSError * __autoreleasing *)error;
- (BOOL)setString:(NSString *)string forKey:(NSString *)key label:(NSString *)label comment:(NSString *)comment error:(NSError * __autoreleasing *)error;

- (BOOL)setData:(NSData *)data forKey:(NSString *)key error:(NSError * __autoreleasing *)error;
- (BOOL)setData:(NSData *)data forKey:(NSString *)key label:(NSString *)label comment:(NSString *)comment error:(NSError * __autoreleasing *)error;

- (NSString *)stringForKey:(NSString *)key error:(NSError * __autoreleasing *)error;
- (NSData *)dataForKey:(NSString *)key error:(NSError * __autoreleasing *)error;

+ (BOOL)removeItemForKey:(NSString *)key error:(NSError * __autoreleasing *)error;
+ (BOOL)removeItemForKey:(NSString *)key service:(NSString *)service error:(NSError * __autoreleasing *)error;
+ (BOOL)removeItemForKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup error:(NSError * __autoreleasing *)error;

+ (BOOL)removeAllItemsWithError:(NSError * __autoreleasing *)error;
+ (BOOL)removeAllItemsForService:(NSString *)service error:(NSError * __autoreleasing *)error;
+ (BOOL)removeAllItemsForService:(NSString *)service accessGroup:(NSString *)accessGroup error:(NSError * __autoreleasing *)error;

- (BOOL)removeItemForKey:(NSString *)key error:(NSError * __autoreleasing *)error;
- (BOOL)removeAllItemsWithError:(NSError * __autoreleasing *)error;

@end

@interface VietIdKeyChainStore (ForwardCompatibility)

+ (BOOL)setString:(NSString *)value forKey:(NSString *)key genericAttribute:(id)genericAttribute;
+ (BOOL)setString:(NSString *)value forKey:(NSString *)key genericAttribute:(id)genericAttribute error:(NSError * __autoreleasing *)error;

+ (BOOL)setString:(NSString *)value forKey:(NSString *)key service:(NSString *)service genericAttribute:(id)genericAttribute;
+ (BOOL)setString:(NSString *)value forKey:(NSString *)key service:(NSString *)service genericAttribute:(id)genericAttribute error:(NSError * __autoreleasing *)error;

+ (BOOL)setString:(NSString *)value forKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup genericAttribute:(id)genericAttribute;
+ (BOOL)setString:(NSString *)value forKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup genericAttribute:(id)genericAttribute error:(NSError * __autoreleasing *)error;

+ (BOOL)setData:(NSData *)data forKey:(NSString *)key genericAttribute:(id)genericAttribute;
+ (BOOL)setData:(NSData *)data forKey:(NSString *)key genericAttribute:(id)genericAttribute error:(NSError * __autoreleasing *)error;

+ (BOOL)setData:(NSData *)data forKey:(NSString *)key service:(NSString *)service genericAttribute:(id)genericAttribute;
+ (BOOL)setData:(NSData *)data forKey:(NSString *)key service:(NSString *)service genericAttribute:(id)genericAttribute error:(NSError * __autoreleasing *)error;

+ (BOOL)setData:(NSData *)data forKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup genericAttribute:(id)genericAttribute;
+ (BOOL)setData:(NSData *)data forKey:(NSString *)key service:(NSString *)service accessGroup:(NSString *)accessGroup genericAttribute:(id)genericAttribute error:(NSError * __autoreleasing *)error;

- (BOOL)setString:(NSString *)string forKey:(NSString *)key genericAttribute:(id)genericAttribute;
- (BOOL)setString:(NSString *)string forKey:(NSString *)key genericAttribute:(id)genericAttribute error:(NSError * __autoreleasing *)error;

- (BOOL)setData:(NSData *)data forKey:(NSString *)key genericAttribute:(id)genericAttribute;
- (BOOL)setData:(NSData *)data forKey:(NSString *)key genericAttribute:(id)genericAttribute error:(NSError * __autoreleasing *)error;

@end

@interface VietIdKeyChainStore (Deprecation)

//- (void)synchronize __attribute__((deprecated("calling this method is no longer required")));
//- (BOOL)synchronizeWithError:(NSError *__autoreleasing *)error __attribute__((deprecated("calling this method is no longer required")));

@end
